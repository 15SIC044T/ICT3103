<!DOCTYPE html>
<html lang="en">
    <?php include "header.php" ?>  
    <body>
        <?php include "navbar.php" ?>

        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <?php echo "<h1>" . $_SESSION['SESS_USERNAME'] . "'s File Manager</h1>" ?>

                    
                </div>
            </div>
        </div>
    </div>  
</body>
</html>