<!-- Start of Bottom Navigation: Fixed position -->
<div id="footer">
    <div class="container-fluid" style="background-color: #EDE9DD;">
        <div class="row" style="background-color: #EDE9DD; padding-left:5em; color: #777; height: 30px;">(C) Copyright | All Right Reserved 2017</div>
    </div>
</div>
<!-- End of Bottom Navigation: Fixed position -->